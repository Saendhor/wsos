<!DOCTYPE html>
<html>
<body>

<h2>Welcome to the example!</h2>
<p>Some text.</p>
<p>Some more text.</p>
<p>Included footer follows.<p>
<?php include 'footer.php';?>

</body>
</html>
