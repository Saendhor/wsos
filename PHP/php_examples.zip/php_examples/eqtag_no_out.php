<!-- eqtag_no_out.php -->

<!-- strano esempio sottopostomi a lezione -->

<!DOCTYPE html>
<html><body>

Lo script PHP qui sotto produrr&agrave; i tag <tt>&lt;?= ... =&gt;</tt> 
nell'output HTML inviato al browser; <BR>tale tag, quindi, non produrr&agrave; 
alcun output nel rendering

<?php
   echo '<?= PHP_INT_MAX ?>'; ?>

</body></html>
