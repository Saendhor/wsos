<!-- escape_for.php -->

<?php for ($i = 0; $i < 3; ++$i): ?>
Hello, there!<BR>
<?php endfor; ?>
