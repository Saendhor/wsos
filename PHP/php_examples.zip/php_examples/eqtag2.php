<!-- eqtag2.php -->

PHP tag below:<BR><BR>
<?php $x = 1; ?>
PHP tag below:<BR>
<?= $x += 10; ?>
<BR>PHP tag below:<BR>
<?php echo($x += 10); ?>
