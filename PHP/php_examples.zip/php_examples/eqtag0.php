<!-- eqtag0.php -->

<!DOCTYPE html>
<html><body>
<?= $x = 100; ?>

</body></html>
