<?php $__env->startSection('content'); ?>
    <h1>Create Task</h1>
    <form action="/tasks" method="post">
        <?php echo csrf_field(); ?>
        <label for="title">Title</label> <br>
        <input type="text" name="title" id="title"> <br><br>
        <label for="description">Description</label> <br>
        <textarea name="description" id="description" cols="30" rows="10"></textarea> <br><br>
        <label for="project_id">Project ID</label> <br>
        <input type="number" name="project_id" id="project_id"> <br><br>
        <input type="submit" value="Create Task">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gp/tsdw@s12/larademo/demo2025/resources/views/tasks/create.blade.php ENDPATH**/ ?>