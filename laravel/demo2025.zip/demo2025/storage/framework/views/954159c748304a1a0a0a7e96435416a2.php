<?php $__env->startSection('content'); ?>
    <h1>Tasks</h1>
    <ul>
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li> <a href="/tasks/<?php echo e($task->id); ?>"><?php echo e($task->title); ?></a> </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gp/tsdw@s12/larademo/demo2025/resources/views/tasks/index.blade.php ENDPATH**/ ?>