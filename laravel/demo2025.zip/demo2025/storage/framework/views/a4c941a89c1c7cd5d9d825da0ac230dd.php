<?php $__env->startSection('content'); ?>
    <h1>Project <?php echo e($project->id); ?></h1>
    <b>TITLE:</b> <?php echo e($project->title); ?> <br>
    <b>DESCRIPTION:</b> <?php echo e($project->description); ?> <br>
    <br>
    <form action="/projects/<?php echo e($project->id); ?>/edit" method="get">
        <input type="submit" value="Edit/Delete Project"> <br><br>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gp/tsdw1/demo2025/resources/views/projects/show.blade.php ENDPATH**/ ?>