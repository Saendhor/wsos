<?php
    use App\Models\Project;

    $project = Project::findOrFail($task->project_id);
?>

<?php $__env->startSection('content'); ?>
    <h1>Task <?php echo e($task->id); ?></h1>
    <b>TITLE:</b> <?php echo e($task->title); ?> <br>
    <b>DESCRIPTION:</b> <?php echo e($task->description); ?> <br>
    <b>FROM PROJECT:</b> <a href="/projects/<?php echo e($project->id); ?>"><?php echo e($project->title); ?></a> <br>
    <b>DAL PROGETTO:</b> <a href="/projects/<?php echo e($task->project->id); ?>"><?php echo e($task->project->title); ?></a> <br><br>
    <form action="/tasks/<?php echo e($task->id); ?>/edit" method="get">
        <input type="submit" value="Edit/Delete Task">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gp/tsdw@s12/larademo/demo2025/resources/views/tasks/show.blade.php ENDPATH**/ ?>