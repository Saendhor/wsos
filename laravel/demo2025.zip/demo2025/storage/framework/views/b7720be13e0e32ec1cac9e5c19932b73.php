<?php $__env->startSection('content'); ?>
    <h1>Projects Operations</h1>

    <form action="/projects/create" method="get">
        <input type="submit" value="Create Project"> <br><br>
    </form>

    <form action="/projects" method="get">
        <input type="submit" value="Show All Projects"> <br><br>
    </form>

    <form action="/projects/help_show" method="post">
        <input type="submit" value="Search Project by numeric ID">
        <?php echo csrf_field(); ?>
        <input type="number" name="id" id="id"><br><br>
    </form>

    <form action="/projects" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <input type="submit" value="Delete All Projects"> <br><br>
    </form>

    <h1>Tasks Operations</h1>

    <form action="/tasks/create" method="get">
        <input type="submit" value="Create Task"> <br><br>
    </form>

    <form action="/tasks" method="get">
        <input type="submit" value="Show All Tasks"> <br><br>
    </form>

    <form action="/tasks/help_show" method="post">
        <?php echo csrf_field(); ?>
        <input type="submit" value="Search Task by numeric ID">
        <input type="number" name="id" id="id"> <br><br>
    </form>

    <form action="/tasks" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <input type="submit" value="Delete All Tasks">
    </form>
    <br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gp/tsdw@s12/larademo/demo2025/resources/views/home.blade.php ENDPATH**/ ?>