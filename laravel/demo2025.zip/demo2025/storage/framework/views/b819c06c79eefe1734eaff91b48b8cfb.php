<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>
        <?php echo $__env->yieldContent('title', 'demo'); ?>
    </title>
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
</body>
<footer>
    <br>
    <hr width="40%" style="text-align:left;margin-left:0">
    <a href="/">Home</a><BR>
    <a href="/README.md">Show README.md</a>
</footer>
</html>
<?php /**PATH /home/gp/tsdw@s12/larademo/demo2025/resources/views/layout.blade.php ENDPATH**/ ?>