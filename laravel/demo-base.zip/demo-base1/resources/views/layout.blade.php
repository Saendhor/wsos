<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>
        @yield('title', 'demo')
    </title>
</head>
<body>
    @yield('content')
</body>
<footer>
    <br>
    <hr width="40%" style="text-align:left;margin-left:0">
    <a href="/">Home</a><BR>
    <a href="/README.md">Show README.md</a>
</footer>
</html>
