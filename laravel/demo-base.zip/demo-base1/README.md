## Setup iniziale

1. Installare il database
   - accertarsi che *mysql*/*mariadb* sia avviato
   - eseguire (su Unix premettere `sudo`, vi verrà chiesta la password di root)
     ```shell
     mysql -u root < mysql_setup.sql 
     ```

1. Copiare 
   ```bash
   rsync
   ```
1. Deploy


